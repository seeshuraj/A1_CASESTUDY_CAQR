# please Use Makefile to run the code
# There is Two folder C_Code and ipynb for plot notebook 

since there is no modle liblapacke available on callan chuck and seagull system for #include <lapacke.h> header file.
I have executed the code on my custom system on Azure system, system config as below

4-core • 16GB RAM • 32GB ROM 

configurations :

        "name": "Linux",
        "compilerPath": "/usr/bin/g++",
        "cStandard": "c17",
        "cppStandard": "c++14",
        "intelliSenseMode": "linux-clang-x64"
